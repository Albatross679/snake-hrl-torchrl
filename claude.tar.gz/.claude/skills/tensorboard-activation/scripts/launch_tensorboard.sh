#!/usr/bin/env bash
# Launch TensorBoard on a specified logdir and port.
# Usage: launch_tensorboard.sh <logdir> [port]
#
# Steps:
#   1. Kill any existing process on the target port
#   2. Verify the port is free
#   3. Start TensorBoard with nohup
#   4. Wait and verify it is serving (HTTP 200)

set -euo pipefail

LOGDIR="${1:?Usage: launch_tensorboard.sh <logdir> [port]}"
PORT="${2:-6006}"
LOGFILE="/tmp/tensorboard_${PORT}.log"

# Validate logdir exists and contains event files
if [ ! -d "$LOGDIR" ]; then
  echo "ERROR: Log directory does not exist: $LOGDIR" >&2
  exit 1
fi

EVENT_COUNT=$(find "$LOGDIR" -name 'events.out.tfevents.*' 2>/dev/null | wc -l)
if [ "$EVENT_COUNT" -eq 0 ]; then
  echo "WARNING: No TensorBoard event files found in $LOGDIR" >&2
fi

# Kill any process occupying the port
if command -v fuser &>/dev/null; then
  fuser -k "${PORT}/tcp" 2>/dev/null || true
elif command -v lsof &>/dev/null; then
  kill $(lsof -t -i:"$PORT") 2>/dev/null || true
else
  echo "WARNING: Neither fuser nor lsof available; cannot check port $PORT" >&2
fi

sleep 2

# Confirm port is free
if command -v fuser &>/dev/null; then
  if fuser "${PORT}/tcp" 2>/dev/null; then
    echo "ERROR: Port $PORT is still in use after kill attempt" >&2
    exit 1
  fi
fi

echo "Starting TensorBoard on port $PORT..."
echo "  logdir: $LOGDIR"
echo "  logfile: $LOGFILE"

nohup tensorboard --logdir="$LOGDIR" --port="$PORT" --bind_all > "$LOGFILE" 2>&1 &
TB_PID=$!

# Wait for TensorBoard to start serving
MAX_WAIT=10
for i in $(seq 1 $MAX_WAIT); do
  sleep 1
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}" 2>/dev/null || echo "000")
  if [ "$HTTP_CODE" = "200" ]; then
    echo "TensorBoard is running (PID $TB_PID)"
    echo "  Local URL: http://localhost:${PORT}"
    echo ""
    echo "To access remotely via SSH tunnel, run on your LOCAL machine:"
    echo "  ssh -L ${PORT}:localhost:${PORT} <your-ssh-connection>"
    echo "Then open: http://localhost:${PORT}"
    exit 0
  fi
done

echo "ERROR: TensorBoard did not respond within ${MAX_WAIT}s. Check $LOGFILE" >&2
cat "$LOGFILE" >&2
exit 1
